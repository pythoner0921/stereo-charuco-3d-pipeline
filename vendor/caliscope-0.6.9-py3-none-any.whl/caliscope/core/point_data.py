# caliscope/core/point_data.py

from __future__ import annotations
import logging
from pathlib import Path
from time import time
import numpy as np
from numpy.typing import NDArray
import pandas as pd
import pandera.pandas as pa
from numba import jit
from numba.typed import Dict, List
from pandera.typing import Series
from scipy.signal import butter, filtfilt
from caliscope.cameras.camera_array import CameraArray
from dataclasses import dataclass

logger = logging.getLogger(__name__)


#####################################################################################
# The following code is adapted from the `Anipose` project,
# in particular the `triangulate_simple` function of `aniposelib`
# Original author:  Lili Karashchuk
# Project: https://github.com/lambdaloop/aniposelib/
# Original Source Code : https://github.com/lambdaloop/aniposelib/blob/d03b485c4e178d7cff076e9fe1ac36837db49158/aniposelib/cameras.py#L21
# This code is licensed under the BSD 2-Clause License
# BSD 2-Clause License

# Copyright (c) 2019, Lili Karashchuk
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.

# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


@jit(nopython=True, cache=True)
def triangulate_sync_index(
    projection_matrices: Dict, current_camera_indices: np.ndarray, current_point_id: np.ndarray, current_img: np.ndarray
):
    """A more optimized Numba function to triangulate points for a single sync_index."""
    # Numba typed containers are JIT-compiled; static type checkers can't introspect them
    point_indices_xyz = List()  # type: ignore[reportCallIssue]
    obj_xyz = List()  # type: ignore[reportCallIssue]

    # Exit early if there's not enough data to form a pair
    if len(current_point_id) < 2:
        return point_indices_xyz, obj_xyz

    # Sort by point_id to group all observations of the same point together
    sort_indices = np.argsort(current_point_id)
    sorted_points = current_point_id[sort_indices]
    sorted_cams = current_camera_indices[sort_indices]
    sorted_img = current_img[sort_indices]

    group_start = 0
    # Iterate through the sorted arrays to find groups of points
    for i in range(1, len(sorted_points)):
        # A new group starts when the point_id changes
        if sorted_points[i] != sorted_points[group_start]:
            # Process the previous group if it has enough views
            if i - group_start > 1:
                point = sorted_points[group_start]
                points_xy = sorted_img[group_start:i]
                camera_ids = sorted_cams[group_start:i]
                num_cams = len(camera_ids)

                A = np.zeros((num_cams * 2, 4))
                for j in range(num_cams):
                    x, y = points_xy[j]
                    P = projection_matrices[camera_ids[j]]
                    A[(j * 2) : (j * 2 + 1)] = x * P[2] - P[0]
                    A[(j * 2 + 1) : (j * 2 + 2)] = y * P[2] - P[1]

                u, s, vh = np.linalg.svd(A, full_matrices=True)
                point_xyzw = vh[-1]
                point_xyz = point_xyzw[:3] / point_xyzw[3]
                point_indices_xyz.append(point)
                obj_xyz.append(point_xyz)

            # Start the new group
            group_start = i

    # Process the final group after the loop finishes
    if len(sorted_points) - group_start > 1:
        point = sorted_points[group_start]
        # Slicing to the end is implicit
        points_xy = sorted_img[group_start:]
        camera_ids = sorted_cams[group_start:]
        # ... (SVD logic repeated for the last group - could be refactored)
        num_cams = len(camera_ids)
        A = np.zeros((num_cams * 2, 4))
        for j in range(num_cams):
            x, y = points_xy[j]
            P = projection_matrices[camera_ids[j]]
            A[(j * 2) : (j * 2 + 1)] = x * P[2] - P[0]
            A[(j * 2 + 1) : (j * 2 + 2)] = y * P[2] - P[1]

        u, s, vh = np.linalg.svd(A, full_matrices=True)
        point_xyzw = vh[-1]
        point_xyz = point_xyzw[:3] / point_xyzw[3]
        point_indices_xyz.append(point)
        obj_xyz.append(point_xyz)

    return point_indices_xyz, obj_xyz


############################################################################################


def _undistort_batch(xy_df: pd.DataFrame, camera_array: CameraArray) -> pd.DataFrame:
    """Module-private helper to undistort all points in a DataFrame."""
    undistorted_points = []
    for port, camera in camera_array.cameras.items():
        subset_xy = xy_df.query(f"port == {port}").copy()
        if not subset_xy.empty:
            points = np.vstack([subset_xy["img_loc_x"], subset_xy["img_loc_y"]]).T
            undistorted_xy = camera.undistort_points(points, output="normalized")
            subset_xy["img_loc_undistort_x"] = undistorted_xy[:, 0]
            subset_xy["img_loc_undistort_y"] = undistorted_xy[:, 1]
            undistorted_points.append(subset_xy)

    if not undistorted_points:
        return pd.DataFrame()

    xy_undistorted_df = pd.concat(undistorted_points)
    return xy_undistorted_df


class ImagePointSchema(pa.DataFrameModel):
    """Pandera schema for validating 2D (x,y) point data."""

    sync_index: Series[int] = pa.Field(coerce=True)
    port: Series[int] = pa.Field(coerce=True)
    point_id: Series[int] = pa.Field(coerce=True)
    img_loc_x: Series[float] = pa.Field(coerce=True)
    img_loc_y: Series[float] = pa.Field(coerce=True)
    obj_loc_x: Series[float] = pa.Field(coerce=True, nullable=True)
    obj_loc_y: Series[float] = pa.Field(coerce=True, nullable=True)
    obj_loc_z: Series[float] = pa.Field(coerce=True, nullable=True)

    class Config(pa.DataFrameModel.Config):
        strict = False
        coerce = True


class WorldPointSchema(pa.DataFrameModel):
    """Pandera schema for validating 3D (x,y,z) point data."""

    sync_index: Series[int] = pa.Field(coerce=True)
    point_id: Series[int] = pa.Field(coerce=True)
    x_coord: Series[float] = pa.Field(coerce=True)
    y_coord: Series[float] = pa.Field(coerce=True)
    z_coord: Series[float] = pa.Field(coerce=True)
    frame_time: Series[float] = pa.Field(coerce=True, nullable=True)

    class Config(pa.DataFrameModel.Config):
        strict = False
        coerce = True


class ImagePoints:
    """A validated, immutable container for 2D (x,y) point data."""

    _df: pd.DataFrame

    @property
    def df(self) -> pd.DataFrame:
        return self._df.copy()

    def __init__(self, df: pd.DataFrame):
        # Ensure optional columns exist even if not in source data
        df = df.copy()  # Don't modify the original DataFrame
        for col in ["obj_loc_x", "obj_loc_y", "obj_loc_z", "frame_time"]:
            if col not in df.columns:
                df[col] = np.nan

        self._df = ImagePointSchema.validate(df)

    @classmethod
    def from_csv(cls, path: str | Path) -> ImagePoints:
        df = pd.read_csv(path)
        # Constructor handles adding missing optional columns
        return cls(df)

    def fill_gaps(self, max_gap_size: int = 3) -> ImagePoints:
        xy_filled = pd.DataFrame()
        index_key = "sync_index"
        last_port = -1
        base_df = self.df
        for (port, point_id), group in base_df.groupby(["port", "point_id"]):
            if last_port != port:
                logger.info(
                    f"Gap filling for (x,y) data from port {port}. "
                    f"Filling gaps that are {max_gap_size} frames or less..."
                )
            last_port = port
            group = group.sort_values(index_key)
            all_frames = pd.DataFrame({index_key: np.arange(group[index_key].min(), group[index_key].max() + 1)})
            all_frames["port"] = int(port)  # type: ignore[arg-type]
            all_frames["point_id"] = int(point_id)  # type: ignore[arg-type]
            merged = pd.merge(all_frames, group, on=["port", "point_id", index_key], how="left")
            merged["gap_size"] = (
                merged["img_loc_x"].isnull().astype(int).groupby((merged["img_loc_x"].notnull()).cumsum()).cumsum()
            )
            merged = merged[merged["gap_size"] <= max_gap_size]
            for col in ["img_loc_x", "img_loc_y", "frame_time"]:
                if col in merged.columns:
                    merged[col] = merged[col].interpolate(method="linear", limit=max_gap_size)
            xy_filled = pd.concat([xy_filled, merged])
        logger.info("(x,y) gap filling complete")
        return ImagePoints(xy_filled.dropna(subset=["img_loc_x"]))

    def triangulate(self, camera_array: CameraArray) -> WorldPoints:
        """
        Triangulates 2D points to create 3D points using the provided CameraArray.
        The input 2D points are undistorted as part of this process.
        """
        xy_df = self.df
        if xy_df.empty:
            return WorldPoints(pd.DataFrame(columns=list(WorldPointSchema.to_schema().columns.keys())))

        # Only process cameras that are both in data AND posed
        ports_in_data = xy_df["port"].unique()
        posed_ports = list(camera_array.posed_port_to_index.keys())
        valid_ports = [p for p in ports_in_data if p in posed_ports]

        if not valid_ports:
            logger.warning("No cameras in data have extrinsics for triangulation")
            return WorldPoints(pd.DataFrame(columns=list(WorldPointSchema.to_schema().columns.keys())))

        # Assemble numba compatible dictionary for projection matrices
        # This already filters to posed cameras
        normalized_projection_matrices = camera_array.normalized_projection_matrices

        # Undistort all image points before triangulation
        undistorted_xy = _undistort_batch(xy_df, camera_array)

        # Compute mean frame_time per sync_index to carry through triangulation
        frame_times = xy_df.groupby("sync_index")["frame_time"].mean()

        xyz_data = {
            "sync_index": [],
            "point_id": [],
            "x_coord": [],
            "y_coord": [],
            "z_coord": [],
            "frame_time": [],
        }

        # sync_index_max = xy_df["sync_index"].max()
        start = time()
        last_log_update = int(start)

        logger.info("About to begin triangulation...due to jit, first round of calculations may take a moment.")

        # Only iterate over sync indices that have data from valid ports
        valid_sync_indices = undistorted_xy[undistorted_xy["port"].isin(valid_ports)]["sync_index"].unique()

        sync_index_counter = 0
        total_sync_indices = len(valid_sync_indices)

        for index in valid_sync_indices:
            sync_index_counter += 1  # used for tracking progress
            active_index = undistorted_xy["sync_index"] == index
            # Filter to valid ports for this sync index
            index_data = undistorted_xy[active_index & undistorted_xy["port"].isin(valid_ports)]

            if index_data.empty:
                continue

            port = index_data["port"].to_numpy()
            point_ids = index_data["point_id"].to_numpy()
            img_loc_x = index_data["img_loc_undistort_x"].to_numpy()
            img_loc_y = index_data["img_loc_undistort_y"].to_numpy()
            raw_xy = np.vstack([img_loc_x, img_loc_y]).T

            point_id_xyz, points_xyz = triangulate_sync_index(normalized_projection_matrices, port, point_ids, raw_xy)

            if len(point_id_xyz) > 0:
                xyz_data["sync_index"].extend([index] * len(point_id_xyz))
                xyz_data["point_id"].extend(point_id_xyz)
                points_xyz_arr = np.array(points_xyz)
                xyz_data["x_coord"].extend(points_xyz_arr[:, 0].tolist())
                xyz_data["y_coord"].extend(points_xyz_arr[:, 1].tolist())
                xyz_data["z_coord"].extend(points_xyz_arr[:, 2].tolist())
                xyz_data["frame_time"].extend([frame_times[index]] * len(point_id_xyz))

            if int(time()) - last_log_update >= 1:
                percent_complete = int(100 * (sync_index_counter / total_sync_indices))
                logger.info(f"Triangulation of (x,y) point estimates is {percent_complete}% complete")
                last_log_update = int(time())

        xyz_df = pd.DataFrame(xyz_data)
        return WorldPoints(xyz_df)


@dataclass(frozen=True)
class WorldPoints:
    """A validated, immutable container for 3D (x,y,z) point data."""

    _df: pd.DataFrame
    min_index: int | None = None
    max_index: int | None = None

    def __post_init__(self):
        # Validate schema
        object.__setattr__(self, "_df", WorldPointSchema.validate(self._df))

        # calculate start and stop index
        min_index = int(self._df["sync_index"].min())
        max_index = int(self._df["sync_index"].max())
        object.__setattr__(self, "min_index", min_index)
        object.__setattr__(self, "max_index", max_index)

    @property
    def df(self) -> pd.DataFrame:
        """Return a copy of the underlying DataFrame to maintain immutability."""
        return self._df.copy()

    @property
    def points(self) -> NDArray:
        """Return Nx3 numpy array of coordinates."""
        return self._df[["x_coord", "y_coord", "z_coord"]].values

    def fill_gaps(self, max_gap_size: int = 3) -> WorldPoints:
        """Fill gaps in 3D point trajectories."""
        xyz_filled = pd.DataFrame()
        base_df = self.df

        for point_id, group in base_df.groupby("point_id"):
            group = group.sort_values("sync_index")
            all_frames = pd.DataFrame(
                {"sync_index": np.arange(group["sync_index"].min(), group["sync_index"].max() + 1)}
            )
            all_frames["point_id"] = point_id
            merged = pd.merge(all_frames, group, on=["point_id", "sync_index"], how="left")

            # Calculate gap size
            merged["gap_size"] = (
                merged["x_coord"].isnull().astype(int).groupby((merged["x_coord"].notnull()).cumsum()).cumsum()
            )
            merged = merged[merged["gap_size"] <= max_gap_size]

            # Interpolate coordinates and frame_time
            for col in ["x_coord", "y_coord", "z_coord", "frame_time"]:
                if col in merged.columns:
                    merged[col] = merged[col].interpolate(method="linear", limit=max_gap_size)

            xyz_filled = pd.concat([xyz_filled, merged])

        # Return new WorldPoints instance (immutable pattern)
        return WorldPoints(xyz_filled.dropna(subset=["x_coord"]))

    def smooth(self, fps: float, cutoff_freq: float, order: int = 2) -> WorldPoints:
        """Apply Butterworth filter to smooth 3D trajectories."""
        # output="ba" returns (b, a) coefficients; scipy stubs don't narrow this
        b, a = butter(order, cutoff_freq, btype="low", fs=fps, output="ba")  # type: ignore[assignment]
        base_df = self.df
        xyz_filtered = base_df.copy()

        for point_id, group in base_df.groupby("point_id"):
            if group.shape[0] > 3 * order:
                xyz_filtered.loc[group.index, "x_coord"] = filtfilt(b, a, group["x_coord"])
                xyz_filtered.loc[group.index, "y_coord"] = filtfilt(b, a, group["y_coord"])
                xyz_filtered.loc[group.index, "z_coord"] = filtfilt(b, a, group["z_coord"])

        # Return new WorldPoints instance (immutable pattern)
        return WorldPoints(xyz_filtered)

    @classmethod
    def from_csv(cls, path: str | Path) -> WorldPoints:
        """Load WorldPoints from a CSV file.

        Expected columns: sync_index, point_id, x_coord, y_coord, z_coord
        Optional: frame_time (nullable)
        """
        df = pd.read_csv(path)
        return cls(df)  # Constructor handles validation via WorldPointSchema
